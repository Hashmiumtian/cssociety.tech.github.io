<?php


$nm=$_GET["nm"];




?>