# Web-Development-Project-1

A University Club Management System built.
Different University Home Pages, Admin Login Panel, Cool UI, Secured Database! 
 Using PHP and MySQL-JavaScript-HTML-CSS-Bootstrap-Jquery-Ajax
