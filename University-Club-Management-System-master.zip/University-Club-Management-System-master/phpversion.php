<!DOCTYPE html>
<html>
<head>
	<title>php version</title>
</head>
<body>

 <?php
  echo 'Current PHP version: '.phpversion();

 ?>

</body>
</html>